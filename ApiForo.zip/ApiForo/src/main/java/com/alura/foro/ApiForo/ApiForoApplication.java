package com.alura.foro.ApiForo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiForoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiForoApplication.class, args);
	}

}
