package com.alura.foro.ApiForo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiForoApplicationTests {

	@Test
	void contextLoads() {
	}

}
